import React, { Component } from 'react';

class DashboardComponent extends Component {
    constructor(props){
        super(props)
    
        this.state = {
            
        }
       }
   
    render() {
        return(
        <div>
        <h2 className="text-center">Dashboard Page</h2>
            <h3>Dashboard</h3>
        </div>
        );
    };
};


export default DashboardComponent;