import React, { Component } from 'react';

class JobsComponent extends Component {
    constructor(props){
        super(props)
    
        this.state = {
            
        }
       }
   
    render() {
        return(
        <div>
        <h2 className="text-center">Jobs Page</h2>
            <h3>Jobs</h3>
        </div>
        );
    };
}

export default JobsComponent;