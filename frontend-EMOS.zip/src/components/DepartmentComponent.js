import React, { Component } from 'react';

class DepartmentComponent extends Component {
    constructor(props){
        super(props)
    
        this.state = {
            
        }
       }
   
    render() {
        return(
        <div>
        <h2 className="text-center">Department Page</h2>
            <h3>Department</h3>
        </div>
        );
    };
};


export default DepartmentComponent;